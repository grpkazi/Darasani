<!DOCTYPE html>
<html>
<head><title></title>
<style type="text/css">
		  body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
	</style>
</head>
<body>
	<table border="1" style="border-collapse: collapse" align="center">
<tr>
<td>Sno</td>
<td>First Name</td>
<td>Midle Name</td>
<td>Last Name</td>
<td>Email</td>
<td>Phone Numbe</td>
<td>Edit</td>
<td>Delete</td>
</tr>
<a href="logout.php">logout</a>
<a href="excelfile.php">Create Excel Report</a>




<?php

require_once('connection.php');
$sql="SELECT * FROM usafiri";
$query=mysqli_query($conn,$sql);
$n=1;
while($rw=mysqli_fetch_array($query))
{

	$k=$rw['id'];
$fname=$rw["fname"];
$mname=$rw["mname"];
$lname=$rw["lname"];
$email=$rw["email"];
$phone=$rw["phone"];


	echo"<tr>";
		echo"<td>$k</td>";
	echo"<td>$fname</td>";
	echo"<td>$mname</td>";
	echo"<td>$lname</td>";
	echo"<td>$email</td>";
	echo"<td>$phone</td>";
	
	
	
	
	echo"<td><a href='register_update.php? m=$k'>edit</a></td>";
	echo"<td><a href='delete.php? m=$k'>Delete</a></td>";
	echo"</tr>";
	$n++;



}

?>
</table>
</body>
</html>
