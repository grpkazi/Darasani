
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>field area</title>
    <style>
    table{
        text-align:center;
        margin-left:500px;
         padding-left:30px;
         padding-right:30px;
         padding-top:50px;
         padding-bottom:50px;
         border-radius:48px;
         background-color:white;
         /* background-image: url("user.jpg");*/
    }
    td{
        border-radius:26px;
        padding-left:5px;
        padding-right:5px;
        padding-bottom:15px;
        padding-top:25px;
    }
    #capt{
         font-size:30px;
         color:blue;
         font-family:lucida console;
    }
    
     
      body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
          
     
 </style>
</head>
<body>
<div class="mama">
     <table border="0" width="30%" height="50%" align="center">

           <center><b><caption id="capt"><b>VITUO VYA BODABODA</b> </caption></b></center>
<tr>
              <td id="ngoro"><br>
                 <a href="tca.php"> <img src="" width="35px" height="35px"><br></a>
                       <a href="tca.php">KITUO CHA TCA</a>
</td>
<td id="miku">
<br>
<img src="sombetini.jpg" width="35px" height="35px"><br>
<a href="sombetini.php">KITUO CHA SOMBETINI</a>
</td>
</tr>
<tr>
    <td id="sad">
              <br>
              <img src="triple.jpg" height="35px" width="35px"><br>
              <a href="triple.php">KITUO CHA TRIPLE A</a>
         </td>
         <td id="sere">
              <br>
              <img src="traa.jpg" height="35px" width="35px"><br>
              <a href="getini.php">KITUO CHA GETINI</a>
         </td>              
</tr>
<tr>
         <td id="tara">
              <br>
              <img src="councile.jpg" height="35px" width="35px"><br>
              <a href="nextdoor.php">KITUO CHA NEXTDOOR</a>
         </td>
         <td id="manya">
              <br>
              <img src="rama.jpg" height="35px" width="35px"><br>
              <a href="rama.php">KITUO KWA MAMA RAMA</a><br>
              </td>
              </tr>
              <tr>
              <td id="town">
              <br>
              <img src="stand.jpg" height="35px" width="35px"><br>
              <a href="stand.php">KITUO CHA STENDI KUU</a><br>
              </td>
              <td>
              <img src="log_out.png" height="40px" width="40px"><br>
              <a href="login.php">Logout</a><br>
              
         </td>         
</tr>
</table>
</div>
</body>
</html>