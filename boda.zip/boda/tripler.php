<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		  body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
	</style>
</head>
<body>
<h1><b>Asante! kwa kujisajili kikamilifu kwenye mfumo wetu wa jiji la Arusha<br>KUWA MZALENDO TUIJENGE NCHI YETU</b></h1><br><br>
	<table>
		<h1>Fanya malipo hapa kuendelea kupata huduma zetu</h1>
		<tr>
			<td>
				Lipia kwa<select name="lipia" id="lipia">
        <option value="" name="lipia"></option>
         <option value="NONE" name="none">NONE </option>
        <option value="M-PESA" name="health">M-PESA </option>
        <option value="TIGOPESA" name="bach">TIGOPESA </option>
        <option value="AITRTEL MONEY" name="human">AITRTEL MONEY </option>
        <option value="HALOPESA" name="education" >HALOPESA</option>
        <option value="TTCL PESA" name="health">TTCL PESA </option>
        <option value="EZZY PESA" name="bach">EZZY PESA </option>
        <option value="ATM" name="human">ATM </option>
        <option value="MAELEZO" name="education" >KWA MSAADA PIGA 0743554148</option>
</select>
			</td>
			<tr>
<td><a href="recharge.php"><input type="submit" name="lipa" value="lipa" id="batani"></a><br></td>
</tr>
		</tr>

	</table>
</body>
</html>