<?php

if(isset($_POST['login'])){
include('connection.php');
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$sql="SELECT * FROM usafiri WHERE email='$email'";
	$result=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($result);
	$num=mysqli_num_rows($result);
	if($num==1){
	$p=$row['pass'];
	if(password_verify($pass,$p)){
	$role=$row['role'];
	switch($role){
	case 'admin':
	session_start();
	$_SESSION['role']='admin';
	header("location:usajili.php");
	break;
	case 'user':
	session_start();
	$_SESSION['role']='user';
	header("location:list.php");
	break;
	default:
	header("location:login.php"); break;

}
}
else{
	echo "wrong user name or password";

}

}

}
?>

<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<style type="text/css">
		  body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
	</style>
</head>
<body>
<form method="POST">
	<table align="center" align="center">
			<tr><td>Email</td>
			<td><input type="text" name="email"></td></tr>
			<tr><td>Password</td>
			<td><input type="password" name="pass"></td></tr>
			<tr><td colspan="2"><?php 
			 if (isset($error)) {
				echo $error;} 
			?>
			</td></tr>
			<tr>
			<td><a href="reset.php">Reset Password</a></td>
			<td><input type="submit" name="login" value="login"></td>

		</tr>

	</table>

</form>
</body>
</html>