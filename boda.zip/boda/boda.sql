-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2023 at 07:05 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `boda`
--

-- --------------------------------------------------------

--
-- Table structure for table `getini`
--

CREATE TABLE `getini` (
  `id` int(15) NOT NULL,
  `jina` varchar(25) NOT NULL,
  `pikipiki` varchar(20) NOT NULL,
  `simu` varchar(25) NOT NULL,
  `namba` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `getini`
--

INSERT INTO `getini` (`id`, `jina`, `pikipiki`, `simu`, `namba`) VALUES
(1, 'magera mokiwa', 'Boxer', '0758587452', 'T325DLA'),
(2, 'magera mokiwa', 'Boxer', '0758587452', 'T325DLA'),
(3, 'magera mokiwa', 'Boxer', '0758587452', 'T325DLA');

-- --------------------------------------------------------

--
-- Table structure for table `nextdoor`
--

CREATE TABLE `nextdoor` (
  `id` int(15) NOT NULL,
  `jina` varchar(25) NOT NULL,
  `pikipiki` varchar(15) NOT NULL,
  `simu` varchar(100) NOT NULL,
  `namba` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nextdoor`
--

INSERT INTO `nextdoor` (`id`, `jina`, `pikipiki`, `simu`, `namba`) VALUES
(1, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T325DLA'),
(2, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T325DLA'),
(3, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T325DLA'),
(4, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(5, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(6, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(7, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(8, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(9, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(10, '', '', '', ''),
(11, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `rama`
--

CREATE TABLE `rama` (
  `id` int(15) NOT NULL,
  `jina` varchar(50) NOT NULL,
  `pikipiki` varchar(10) NOT NULL,
  `simu` varchar(15) NOT NULL,
  `namba` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rama`
--

INSERT INTO `rama` (`id`, `jina`, `pikipiki`, `simu`, `namba`) VALUES
(1, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(2, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(3, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(4, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(5, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(6, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sombetini`
--

CREATE TABLE `sombetini` (
  `id` int(15) NOT NULL,
  `jina` varchar(11) NOT NULL,
  `pikipiki` varchar(15) NOT NULL,
  `simu` varchar(15) NOT NULL,
  `namba` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sombetini`
--

INSERT INTO `sombetini` (`id`, `jina`, `pikipiki`, `simu`, `namba`) VALUES
(1, 'magera moki', 'Boxer', '0758587452', 'T 789 EBC'),
(2, '', '', '', ''),
(3, '', '', '', ''),
(4, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `stand`
--

CREATE TABLE `stand` (
  `id` int(15) NOT NULL,
  `jina` varchar(25) NOT NULL,
  `pikipiki` varchar(10) NOT NULL,
  `simu` varchar(15) NOT NULL,
  `namba` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stand`
--

INSERT INTO `stand` (`id`, `jina`, `pikipiki`, `simu`, `namba`) VALUES
(1, 'ERICK', 'LAZARO', '0711639507', 'T 789 EBC'),
(2, 'ERICK', 'LAZARO', '0711639507', 'T 789 EBC'),
(3, 'ERICK', 'LAZARO', '0711639507', 'T 789 EBC'),
(4, 'ERICK', 'LAZARO', '0711639507', 'T 789 EBC'),
(5, 'ERICK', 'LAZARO', '0711639507', 'T 789 EBC'),
(6, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tca`
--

CREATE TABLE `tca` (
  `id` int(15) NOT NULL,
  `jina` varchar(25) NOT NULL,
  `pikipiki` varchar(20) NOT NULL,
  `simu` varchar(25) NOT NULL,
  `namba` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tca`
--

INSERT INTO `tca` (`id`, `jina`, `pikipiki`, `simu`, `namba`) VALUES
(4, 'magera mokiwa', 'KINGLION', '0758587452', 'T 789 EBC'),
(7, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(8, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(9, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(10, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(11, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(12, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(13, 'EMANUEL MAHEMBE', 'KINGLION', '0711639507', 'T 789 EBC'),
(14, '', '', '', ''),
(15, '', '', '', ''),
(16, '', '', '', ''),
(17, '', '', '', ''),
(18, '', '', '', ''),
(19, '', '', '', ''),
(20, 'mahembe', 'Boxer', '0711639507', 'T 789 EBC');

-- --------------------------------------------------------

--
-- Table structure for table `transport`
--

CREATE TABLE `transport` (
  `id` int(15) NOT NULL,
  `firrst_name` varchar(50) NOT NULL,
  `second_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transport`
--

INSERT INTO `transport` (`id`, `firrst_name`, `second_name`, `last_name`, `email`, `phone_number`, `Password`) VALUES
(1, 'hassan', '', 'hamza', 'bushiryshabby@gmail.com', '0789765423', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `triple`
--

CREATE TABLE `triple` (
  `id` int(15) NOT NULL,
  `jina` varchar(25) NOT NULL,
  `pikipiki` varchar(20) NOT NULL,
  `simu` varchar(25) NOT NULL,
  `namba` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `triple`
--

INSERT INTO `triple` (`id`, `jina`, `pikipiki`, `simu`, `namba`) VALUES
(1, 'magera mokiwa', 'Boxer', '0758587452', 'T 789 EBC'),
(2, 'magera mokiwa', 'Boxer', '0758587452', 'T325DLA'),
(3, '', '', '', ''),
(4, '', '', '', ''),
(5, '', '', '', ''),
(6, '', '', '', ''),
(7, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `usafiri`
--

CREATE TABLE `usafiri` (
  `id` int(15) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `role` varchar(15) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usafiri`
--

INSERT INTO `usafiri` (`id`, `fname`, `mname`, `lname`, `email`, `phone`, `pass`, `role`) VALUES
(1, 'shaban', 'Hamis', 'Bushiry', 'lepapa@gmail.com', '0789675423', '$2y$10$Djw5OneB0ZtSUsZcGxApteT4iSGUhJBoLGzyKVYlfqYcybsSSMSNa', 'user'),
(2, 'shaban', 'Hamis', 'Bushiry', 'addidasvenas@gmail.com', '0778446708', '$2y$10$KKQQXGN9LETwxhaSb8MdxeWp68BRAIo88FPlfVxj8JTEevUBJC5K2', 'user'),
(3, 'shaban', 'Hamis', 'Bushiry', 'addidasvenas@gmail.com', '0778446708', '$2y$10$nyBiO.RyhehUoBVOdoW3OeozFtdSTEMPKwk0VDrmhbgxgbsV4fs4a', 'user'),
(4, 'shaban', 'Hamis', 'Bushiry', 'addidasvenas@gmail.com', '0778446708', '$2y$10$y7XGaGP8Kq6eYyoq5CROfuBQsa.XQA8Vkd0Tafu11O.YZTovSX7Ce', 'user'),
(5, 'shaban', 'kasseem', 'Bushiry', 'sylivesterj24@gmail.com', '0789675423', '$2y$10$Yi4ZUku4V4/4ZIHG.c7MheLUpBallm.AODmQbK9.na0mcvyr7F88y', 'user'),
(6, 'dan', 'juma', 'inno', 'danij@gmail.com', '0789232134', '$2y$10$ZNBbUlldnf37NZ/cXdsQQ.W5IJPCNnWH0mS9pYecuM9lTsthKKEoq', 'user'),
(7, 'vainess', 'mwanafunz', 'wa 1', 'vainess@gmail.com', '0789675423', '$2y$10$ihWwlBLNUM/M9ahVnfh7PuinAwE7LWvkQ6mK1gjR.icgvo1k/dbWO', 'admin'),
(8, 'shaban', 'Hamis', 'Bushiry', 'bushiryshabby@gmail.com', '0778446708', '$2y$10$b591QMpFIl0CRbQBIOnYJ.JAe2TGb4aU9zucaYOLonGoDedWh8Hz.', 'user'),
(9, 'aman', 'ally', 'issa', 'aman@gmail.com', '0789675423', '$2y$10$Vt3ZZCH6V03NpdYBgqZBa.tXzF8U/suqdoMahJvBPQC.WGsDoDf.O', 'user'),
(10, 'Regina', 'kasseem', 'kanzu', 'regina@gmail.com', '0789675423', '$2y$10$TcV1HKOBuiB1nlHRRzI0ZumFz779mbYdSZ3QDb.d05HJE017fSblC', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `getini`
--
ALTER TABLE `getini`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nextdoor`
--
ALTER TABLE `nextdoor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rama`
--
ALTER TABLE `rama`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sombetini`
--
ALTER TABLE `sombetini`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stand`
--
ALTER TABLE `stand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tca`
--
ALTER TABLE `tca`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transport`
--
ALTER TABLE `transport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `triple`
--
ALTER TABLE `triple`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usafiri`
--
ALTER TABLE `usafiri`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `getini`
--
ALTER TABLE `getini`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `nextdoor`
--
ALTER TABLE `nextdoor`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `rama`
--
ALTER TABLE `rama`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sombetini`
--
ALTER TABLE `sombetini`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stand`
--
ALTER TABLE `stand`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tca`
--
ALTER TABLE `tca`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `transport`
--
ALTER TABLE `transport`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `triple`
--
ALTER TABLE `triple`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `usafiri`
--
ALTER TABLE `usafiri`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
