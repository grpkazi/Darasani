<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1><center>Kiasi ni shilingi 5000 kwa wiki</h1></center>
<table border="1" align="center">
	
	<tr>
		<th>Aina ya mtandao</th>
		<th>Namba ya simu</th>
		<th>Jina kamili</th>
		</tr>

		<tr>
		<td>MPESA</td>
		<td>0743554149</td>		
		<td>Shaban Bushiry</td>
	</tr>
	<tr>
		<td>TIGOPESA</td>
		<td>0712117886</td>		
		<td>Shaban Bushiry</td>
	</tr>
	<tr>
		<td>HALOPESA</td>
		<td>0629736629</td>		
		<td>Shaban Bushiry</td>
	</tr>
	<tr>
		<td>TTCL PESA</td>
		<td>0789654312</td>		
		<td>Shaban Bushiry</td>
	</tr>
	<tr>
		<td>EZZY PESA</td>
		<td>0778446708</td>		
		<td>Shaban Bushiry</td>
	</tr>
	<tr>
		<td>ATM</td>
		<td>0452527625052</td>		
		<td>Shaban Bushiry</td>
	</tr>


</table>
</body>
</html>