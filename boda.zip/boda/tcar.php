<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		  body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
	</style>
</head>
<body>
<h1><b>Asante! kwa kujisajili kikamilifu kwenye mfumo wetu wa jiji la Arusha<br>KUWA MZALENDO TUIJENGE NCHI YETU</b></h1><br><br>
<h4><i>utafikiwa na mteja aliyepo karibu nawe! kwa kupigiwa simu.</i>
</h4><br><br>
<h5><b>kwa usalama zaidi muulize mteja wako jina kamili,</b>
</body>
</html>