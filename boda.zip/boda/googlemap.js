function loadMap() {
	var arushaTechnicalCollege = {lat: 3.3650, lng: 36.6771};
	var map = new google.maps.Map(document.getElementById('map'), {
		zoom: 10,
		center: arushaTechnicalCollege
	});
	var marker = new google.maps.Marker({
		position: arushaTechnicalCollege,
		map: map
	});
}
