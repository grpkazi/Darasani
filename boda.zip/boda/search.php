<form action="search.php" method="GET">
  <input type="text" name="query" placeholder="Enter your search query">
  <input type="submit" value="Search">
</form>

<!-- Inside your search.php script -->
<?php
include("applicant.php");
// Process the search query and retrieve search results
$query = $_GET['query'];
// Perform search operations and obtain results

// Generate HTML for search results
if ($results) {
  echo "<ul>";
  foreach ($results as $result) {
    echo "<li><a href='" . $result['url'] . "'>" . $result['title'] . "</a></li>";
  }
  echo "</ul>";
} else {
  echo "No results found.";
}
?>
