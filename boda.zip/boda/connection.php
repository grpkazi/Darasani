<?php
$conn=mysqli_connect("localhost","root","","boda") or die("not conected");
if($conn){
	echo "";
}else{
	echo"unable to connect";
}
?>