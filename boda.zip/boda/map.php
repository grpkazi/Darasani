<!DOCTYPE html>
<html>
<head>

	<title></title>
	<script type="text/javascript" src="js/googlemap.js"></script>
</head>
<body>
	<center>Access google map</center>
<div></div>
</body>
</html>

AIzaSyD_hd59NiVbOyEckUvvw9rr9FBDbaFfV1I