<?php 
session_start();
if(isset($_SESSION['admin'])){
	if(isset($_GET['id'])){
		$k = $_GET['id'];
		require_once 'includes/connection.php';
		$deleteOrder = "DELETE FROM application WHERE id = '$k'";
		$run = mysqli_query($con,$deleteOrder);
		if($run){
			header('location:myreservations.php');
		}
		else{
			echo "Unexpected Error Occured!";
		}
	}else{
		header('location:admin.php');
	}


}else{
	header('location:login.php');
}





?>