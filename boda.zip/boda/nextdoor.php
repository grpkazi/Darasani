<?php
error_reporting("1");
if(isset($_POST["Register"])){
require_once ('connection.php');
$jina=$_POST["jina"];
$pikipiki=$_POST["pikipiki"];
$simu=$_POST["simu"];
$namba=$_POST["namba"];
$pass=password_hash($password, PASSWORD_DEFAULT);


echo $sql="INSERT INTO nextdoor (jina,pikipiki,simu,namba)VALUES('$jina','$pikipiki','$simu','$namba')";
echo"$sql";
$query=mysqli_query($conn,$sql);

if($query){
	echo"<script>alert('data are sent')</script>";
	header("location:tripler.php");
} 
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		  body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
	</style>
</head>
<body>
	<form method="post" action="">
<table border="0" align="center">
	<tr>
		<center><h1><b>KITUO CHA NEXTDOOR</b></h1></center>
	<tr>
			<td>
				Jina kamili<input type="text" name="jina" id="jina">
			</td>
		</tr>
		<tr>
			<td>
				Aina ya pikipiki<input type="text" name="pikipiki" id="pikipiki">
			</td>
		</tr>
<tr>
			<td>
				Namba ya simu<input type="text" name="simu" id="numba">
			</td>
		</tr>
		<tr>
			<td>
				Namba ya pikipiki<input type="text" name="namba" id="email">
			</td>
		</tr>
		
<tr><td><input type="submit" name="Register" value="Register" id="batani"></td></tr>
</table>
</form>
</body>
</html>