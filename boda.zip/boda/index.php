<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootsrap.min.css">
	<script type="text/javascript" src="js/googlemap.js"></script>
	<style type="text/css">
		.container {
			height: 450px;
		}
		#map {
			width: 100%;
			height: 100%;
			border: 1px solid blue;
		}
	</style>
</head>
<body>
	<div class="container">
		<center><h1>Access Google Maps</h1></center>
		<div id="map"></div>
	</div>
	<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_hd59NiVbOyEckUvvw9rr9FBDbaFfV1Icallback=loadMap">
		
	</script>
</body>
</html>


