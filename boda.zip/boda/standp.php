<!DOCTYPE html>
<html>
<head><title></title>
<style type="text/css">
		  body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
	</style>
</head>
<body>
	<table border="1" style="border-collapse: collapse" align="center">
		<center><h1><b><i>KITUO CHA STENDI KUU</i></b></h1></center>
<tr>
<td>Sno</td>
<td>Jina kamili</td>
<td>Aina ya pikipiki</td>
<td>Namba ya simu</td>
<td>Namba ya pikipiki</td>
</tr>




<?php

require_once('connection.php');
$sql="SELECT * FROM stand";
$query=mysqli_query($conn,$sql);
$n=1;
while($rw=mysqli_fetch_array($query))
{

	$k=$rw['id'];
$jina=$rw["jina"];
$pikipiki=$rw["pikipiki"];
$simu=$rw["simu"];
$namba=$rw["namba"];



	echo"<tr>";
		echo"<td>$k</td>";
	echo"<td>$jina</td>";
	echo"<td>$pikipiki</td>";
	echo"<td>$simu</td>";
	echo"<td>$namba</td>";

	$n++;



}

?>
</table>
</body>
</html>
