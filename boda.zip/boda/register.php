<?php
error_reporting("1");
if(isset($_POST["Register"])){
require_once ('connection.php');
$fname=$_POST["fname"];
$mname=$_POST["mname"];
$lname=$_POST["lname"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$password=$_POST["pass"];
$pass=password_hash($password, PASSWORD_DEFAULT);


echo $sql="INSERT INTO usafiri (fname,mname,lname,email,phone,pass)VALUES('$fname','$mname','$lname','$email','$phone','$pass')";
echo"$sql";
$query=mysqli_query($conn,$sql);

if($query){
	echo"<script>alert('data are sent')</script>";
	header("location:login.php");
} 
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		  body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
	</style>
</head>
<body>
	<form method="post" action="">
<table border="0" align="center">
	<tr>
	<tr>
			<td>
				First Name<input type="text" name="fname" id="fname">
			</td>
		</tr>
		<tr>
			<td>
				Second Name<input type="text" name="mname" id="mname">
			</td>
		</tr>
<tr>
			<td>
				Last Name<input type="text" name="lname" id="lname">
			</td>
		</tr>
		<tr>
			<td>
				Email<input type="text" name="email" id="email">
			</td>
		</tr>
		<tr><td>Phone Number<input type="text" name="phone"></td></tr>
		<tr>
			<td>
				Password<input type="text" name="pass">
			</td>
		</tr>
<tr><td><input type="submit" name="Register" value="Register" id="batani"></td></tr>
</table>
</form>
</body>
</html>