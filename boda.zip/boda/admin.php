<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		  body{
             background-color:aquamarine;
             background-image: url("pm.jpg");
             
         }
	</style>
</head>
<body>
<table align="center">

	<a href="applicant.php">registered</a>&nbsp&nbsp&nbsp&nbsp
	
			<a href="excelfile.php">Excel Report</a>&nbsp&nbsp&nbsp&nbsp
			<a href="post.php">post announcement</a>&nbsp&nbsp&nbsp&nbsp
			<a href="lectures.php">Post lectures</a>&nbsp&nbsp&nbsp&nbsp
<a href="login.php">logout</a>

		
</table>
</body>
</html>